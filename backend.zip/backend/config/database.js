
module.exports={
    database: 'mongodb+srv://workspacemvsi:3fmr4tSsivTHor4I@cluster06.569xw8k.mongodb.net/pet'
    // database:'mongodb://localhost:27017/pet'
}